(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/6120e_3dd5af13._.js",
  "static/chunks/OneDrive_Bureau_resume-matching-platform_frontend_2838e5c9._.js"
],
    source: "dynamic"
});
