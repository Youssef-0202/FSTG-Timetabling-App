(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b94cdac4._.js",
  "static/chunks/6120e_next_dist_compiled_react-dom_b83152e8._.js",
  "static/chunks/6120e_next_dist_compiled_react-server-dom-turbopack_bd425645._.js",
  "static/chunks/6120e_next_dist_compiled_next-devtools_index_b8153c15.js",
  "static/chunks/6120e_next_dist_compiled_6265f78a._.js",
  "static/chunks/6120e_next_dist_client_d8082ade._.js",
  "static/chunks/6120e_next_dist_6dfd1d11._.js",
  "static/chunks/6120e_@swc_helpers_cjs_18e8ba33._.js"
],
    source: "entry"
});
